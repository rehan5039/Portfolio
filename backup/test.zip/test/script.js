document.addEventListener('DOMContentLoaded', () => {
    // Remove loading class after slight delay for initial animations
    setTimeout(() => {
        document.body.classList.remove('loading');
    }, 500);

    // Theme Toggle with smooth transition
    const themeToggle = document.querySelector('.theme-toggle');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    
    // Set initial theme based on system preference or saved preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
        document.body.style.transition = 'none';
        requestAnimationFrame(() => {
            document.body.style.transition = '';
        });
    } else if (prefersDarkScheme.matches) {
        document.documentElement.setAttribute('data-theme', 'dark');
    }

    // Add transition after initial load
    document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';

    // Theme toggle with animation
    themeToggle.addEventListener('click', () => {
        themeToggle.style.transform = 'scale(0.95)';
        setTimeout(() => themeToggle.style.transform = '', 150);

        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    });

    // Navbar scroll behavior
    const header = document.querySelector('.header');
    const navbar = document.querySelector('.nav-wrapper');
    let lastScroll = 0;

    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        // Add/remove scrolled class for background
        if (currentScroll > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }

        // Hide/show navbar on scroll
        if (currentScroll > lastScroll && currentScroll > 500) {
            navbar.style.transform = 'translateY(-100%)';
        } else {
            navbar.style.transform = 'translateY(0)';
        }
        lastScroll = currentScroll;
    });

    // Mobile Navigation with smooth transitions
    const hamburger = document.querySelector('.hamburger');
    const navContent = document.querySelector('.nav-content');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Highlight active section on scroll
    const sections = document.querySelectorAll('section[id]');
    
    function highlightNavigation() {
        const scrollY = window.pageYOffset;
        
        sections.forEach(section => {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop - 100;
            const sectionId = section.getAttribute('id');
            const navigationLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);
            
            if (navigationLink && scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                document.querySelector('.nav-link.active')?.classList.remove('active');
                navigationLink.classList.add('active');
            }
        });
    }

    window.addEventListener('scroll', highlightNavigation);

    // Mobile menu toggle
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navContent.classList.toggle('active');
        document.body.classList.toggle('menu-open');
    });

    // Close mobile menu when clicking links
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navContent.classList.remove('active');
            document.body.classList.remove('menu-open');
        });
    });

    // Back to top button
    const backToTop = document.getElementById('back-to-top');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 500) {
            backToTop.classList.add('visible');
        } else {
            backToTop.classList.remove('visible');
        }
    });

    backToTop.addEventListener('click', (e) => {
        e.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Smooth scrolling with offset
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.offsetTop;
                const offsetPosition = elementPosition - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Animation Utilities
    const easeOutQuart = (x) => 1 - Math.pow(1 - x, 4);

    const animateCounter = (element, target) => {
        const duration = 2000;
        const startTime = performance.now();
        const startValue = 0;
        
        const updateCounter = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easedProgress = easeOutQuart(progress);
            const currentValue = Math.round(startValue + (target - startValue) * easedProgress);
            
            element.textContent = currentValue;
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            }
        };
        
        requestAnimationFrame(updateCounter);
    };

    // Intersection Observer for all animations
    const animationObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;

                // General reveal animation
                element.classList.add('reveal');

                // Specific animations based on element type
                if (element.classList.contains('section')) {
                    element.classList.add('fade-in');
                }

                if (element.classList.contains('progress')) {
                    const percent = element.getAttribute('data-percent');
                    element.style.width = `${percent}%`;
                }

                if (element.classList.contains('circle')) {
                    const percent = element.getAttribute('data-percent');
                    const rotation = (percent / 100) * 360;
                    element.style.setProperty('--rotation', `${rotation}deg`);
                    element.classList.add('animate');
                }

                if (element.classList.contains('stat-number')) {
                    const target = parseInt(element.getAttribute('data-count'));
                    animateCounter(element, target);
                }

                if (element.classList.contains('timeline-item')) {
                    element.classList.add('appear');
                }

                animationObserver.unobserve(element);
            }
        });
    }, {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
    });

    // Observe elements for animation
    document.querySelectorAll(`
        .section,
        .progress,
        .circle,
        .stat-number,
        .timeline-item,
        .portfolio-item,
        .cert-item
    `).forEach(element => {
        element.classList.add('reveal-hidden');
        animationObserver.observe(element);
    });

    // Resume download handler with animation
    document.getElementById('download-resume').addEventListener('click', (e) => {
        e.preventDefault();
        const button = e.currentTarget;
        button.classList.add('downloading');
        
        setTimeout(() => {
            alert('Resume download functionality will be implemented once the PDF is ready.');
            button.classList.remove('downloading');
        }, 1000);
    });

    // Enhanced form submission handling
    const contactForm = document.querySelector('.contact-form');
    let isSubmitting = false;

    const showFormMessage = (message, type) => {
        alert(message); // Replace with a better UI notification system
    };

    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (isSubmitting) return;
        
        const recaptchaResponse = grecaptcha.getResponse();
        if (!recaptchaResponse) {
            showFormMessage('Please complete the reCAPTCHA verification.', 'error');
            return;
        }

        const formData = new FormData(contactForm);
        const submitButton = contactForm.querySelector('button[type="submit"]');
        
        try {
            isSubmitting = true;
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
            
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            showFormMessage('Thank you for your message! I will get back to you soon.', 'success');
            contactForm.reset();
            grecaptcha.reset();
        } catch (error) {
            showFormMessage('There was an error sending your message. Please try again.', 'error');
        } finally {
            isSubmitting = false;
            submitButton.disabled = false;
            submitButton.innerHTML = '<span>Send Message</span><i class="fas fa-paper-plane"></i>';
        }
    });

    // Parallax effect for hero section
    const hero = document.querySelector('.hero');
    const heroContent = document.querySelector('.hero-content');
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const rate = scrolled * 0.5;
        
        hero.style.backgroundPositionY = `${rate}px`;
        heroContent.style.transform = `translateY(${rate * 0.7}px)`;
    });

    // Smooth scrolling for navigation links with offset
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.offsetTop;
                const offsetPosition = elementPosition - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });

                // Close mobile menu if open
                navLinks.classList.remove('active');
                hamburger.classList.remove('active');
            }
        });
    });
});
