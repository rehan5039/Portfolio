document.addEventListener('DOMContentLoaded', () => {
    // Mobile Navigation
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    // Close mobile menu when clicking a link
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
        });
    });

    // Resume download handler
    document.getElementById('download-resume').addEventListener('click', (e) => {
        e.preventDefault();
        alert('Resume download functionality will be implemented once the PDF is ready.');
    });

    // Form submission handling with reCAPTCHA placeholder
    const contactForm = document.querySelector('.contact-form');
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Thank you for your message! I will get back to you soon.');
        contactForm.reset();
    });

    // Animated counter function
    const animateCounter = (element, target) => {
        let current = 0;
        const increment = target / 50; // Divide animation into 50 steps
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                clearInterval(timer);
                element.textContent = Math.round(target);
            } else {
                element.textContent = Math.round(current);
            }
        }, 40); // 2 second total duration (40ms * 50 steps)
    };

    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Animate sections
                if (entry.target.classList.contains('section')) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }

                // Animate progress bars
                if (entry.target.classList.contains('progress')) {
                    const percent = entry.target.getAttribute('data-percent');
                    entry.target.style.width = `${percent}%`;
                }

                // Animate skill circles
                if (entry.target.classList.contains('circle')) {
                    const percent = entry.target.getAttribute('data-percent');
                    entry.target.style.setProperty('--percent', percent);
                    entry.target.querySelector('span').textContent = `${percent}%`;
                    const rotation = (percent / 100) * 360;
                    entry.target.querySelector('::before').style.transform = `rotate(${rotation}deg)`;
                }

                // Animate counters
                if (entry.target.classList.contains('stat-number')) {
                    const target = parseInt(entry.target.getAttribute('data-count'));
                    animateCounter(entry.target, target);
                }

                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements for animation
    document.querySelectorAll('.section').forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        section.style.transition = 'all 0.6s ease-out';
        observer.observe(section);
    });

    document.querySelectorAll('.progress').forEach(bar => {
        observer.observe(bar);
    });

    document.querySelectorAll('.circle').forEach(circle => {
        observer.observe(circle);
    });

    document.querySelectorAll('.stat-number').forEach(stat => {
        observer.observe(stat);
    });

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});
